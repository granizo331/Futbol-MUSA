# ================================================================
# App Shiny mejorada v4 - Perfil de jugadores LaLiga 23/24
# Datos: Opta, Wyscout y Transfermarkt
# ================================================================

options(shiny.maxRequestSize = 300 * 1024^2)

library(shiny)
library(bslib)
library(reactable)
library(dplyr)
library(ggiraph)
library(ggplot2)
library(readxl)
library(jsonlite)
library(png)
library(tidyr)
library(stringr)
library(purrr)
library(lubridate)
library(scales)
library(patchwork)
library(htmltools)

# -------------------------
# Helpers generales
# -------------------------
`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0 || (length(x) == 1 && is.na(x))) y else x
}

first_or <- function(x, default = NA) {
  if (is.null(x) || length(x) == 0 || is.na(x[1])) default else x[1]
}

first_not_na <- function(x) {
  x <- as.character(x)
  x <- x[!is.na(x) & x != ""]
  if (length(x) == 0) NA_character_ else x[1]
}

fmt_id <- function(x) {
  x_chr <- as.character(x)
  x_chr <- str_replace(x_chr, "\\.0$", "")
  x_chr <- str_replace_all(x_chr, "\\s+", "")
  out <- ifelse(str_detect(x_chr, "^[0-9]+$"), str_pad(x_chr, width = 6, pad = "0"), x_chr)
  ifelse(is.na(x_chr) | x_chr == "", NA_character_, out)
}

fmt_num <- function(x, digits = 0) {
  if (is.null(x) || length(x) == 0) return("—")
  x_num <- suppressWarnings(as.numeric(x))
  out <- format(round(x_num, digits), big.mark = ".", decimal.mark = ",", nsmall = digits, trim = TRUE)
  out[is.na(x_num) | !is.finite(x_num)] <- "—"
  out
}

fmt_pct <- function(x, digits = 1) {
  if (is.null(x) || length(x) == 0 || is.na(x[1]) || !is.finite(as.numeric(x[1]))) return("—")
  paste0(fmt_num(x[1], digits), "%")
}

parse_number_safe <- function(x) {
  suppressWarnings(as.numeric(str_extract(as.character(x), "\\d+")))
}

to_bool <- function(x) {
  if (is.logical(x)) return(x)
  as.character(x) %in% c("TRUE", "true", "True", "1", "yes", "Yes")
}

safe_pct <- function(x) {
  if (length(x) == 0 || all(is.na(x))) return(NA_real_)
  mean(as.logical(x), na.rm = TRUE) * 100
}

empty_plot <- function(message = "Sin datos disponibles") {
  ggplot() +
    annotate("text", x = 0, y = 0, label = message, size = 5, fontface = "bold", colour = "grey30") +
    xlim(-1, 1) + ylim(-1, 1) +
    theme_void()
}

plotOutput_fixed <- function(outputId, height = "520px") {
  # Evita que bslib/RStudio Viewer calcule alturas dinamicas exageradas.
  args <- list(outputId = outputId, width = "100%", height = height)
  if ("fill" %in% names(formals(shiny::plotOutput))) {
    args$fill <- FALSE
  }
  do.call(shiny::plotOutput, args)
}

metric_card <- function(label, value, sub = NULL) {
  div(
    class = "metric-card",
    div(class = "metric-label", label),
    div(class = "metric-value", value),
    if (!is.null(sub)) div(class = "metric-sub", sub)
  )
}

pct_style <- function(value) {
  if (is.null(value) || is.na(value)) return(NULL)
  if (value >= 75) {
    list(background = "#D8F3DC", fontWeight = "700")
  } else if (value >= 50) {
    list(background = "#FFF3BF", fontWeight = "600")
  } else {
    list(background = "#FFD6D6", fontWeight = "600")
  }
}

# -------------------------
# Metadatos de métricas
# -------------------------
metric_cols <- c(
  "def_success", "def_activity", "aerial_dominance",
  "offensive_impact", "goal_conversion", "shot_quality",
  "passing_eff", "creativity_index", "verticality",
  "involvement", "progression_index", "penetration"
)

metric_labels <- c(
  def_success = "Éxito defensivo",
  def_activity = "Actividad defensiva",
  aerial_dominance = "Dominio aéreo",
  offensive_impact = "Impacto ofensivo",
  goal_conversion = "Conversión",
  shot_quality = "Calidad de tiro",
  passing_eff = "Eficiencia de pase",
  creativity_index = "Creatividad",
  verticality = "Verticalidad",
  involvement = "Participación",
  progression_index = "Progresión",
  penetration = "Penetración"
)

metric_groups <- tibble(
  metric = metric_cols,
  label = unname(metric_labels[metric_cols]),
  group = c(
    rep("Defensa", 3),
    rep("Ataque", 3),
    rep("Creación", 3),
    rep("Progresión", 3)
  )
)

metric_group_lookup <- setNames(metric_groups$group, metric_groups$metric)

metric_dictionary <- tibble(
  metric = metric_cols,
  nombre = unname(metric_labels[metric_cols]),
  grupo = metric_groups$group,
  descripcion = c(
    "Rendimiento relativo en acciones defensivas exitosas.",
    "Volumen e intensidad de acciones defensivas realizadas.",
    "Capacidad de imponerse en duelos aéreos.",
    "Peso del jugador en acciones ofensivas de valor.",
    "Eficacia para transformar ocasiones en gol.",
    "Calidad media de las situaciones de tiro.",
    "Eficiencia y seguridad en circulación de balón.",
    "Producción creativa en acciones que generan ventajas.",
    "Tendencia a jugar hacia adelante y acelerar ataques.",
    "Nivel de participación global en el juego.",
    "Capacidad para progresar el balón o el equipo.",
    "Capacidad para penetrar líneas rivales."
  )
)

# -------------------------
# Clasificación de lesiones
# -------------------------
injury_to_zone <- function(injury) {
  injury <- str_to_lower(coalesce(as.character(injury), ""))
  case_when(
    str_detect(injury, "corona|covid|virus|\\bflu\\b|fever|quarantine|sickness|stomach|\\bill\\b|rest|fitness") ~ "illness",
    str_detect(injury, "head|facial|eyebrow|nose|eye|jaw|concussion|dental|cheekbone|toothache") ~ "head",
    str_detect(injury, "shoulder|acromioclavicular|collarbone") ~ "shoulder",
    str_detect(injury, "arm|elbow|hand|wrist|metacarpal|thumb|finger") ~ "arm",
    str_detect(injury, "chest|ribs") ~ "chest",
    str_detect(injury, "back|lumbago|lumbar|sciatica|vertebral") ~ "back",
    str_detect(injury, "abdominal|abdomen") ~ "abdomen",
    str_detect(injury, "pelvic|hip|groin|inguinal|pubic|pubalgia|testicle") ~ "groin",
    str_detect(injury, "hamstring") ~ "hamstring",
    str_detect(injury, "knee|meniscus|patellar|cruciate") ~ "knee",
    str_detect(injury, "calf|achilles|tibia|shin|peroneus|fibula") ~ "calf",
    str_detect(injury, "ankle") ~ "ankle",
    str_detect(injury, "foot|toe|arch|plantar|metatarsal|heel") ~ "foot",
    str_detect(injury, "thigh|leg|adductor|muscle|muscular|strain") ~ "thigh",
    TRUE ~ "other"
  )
}

zone_labels <- c(
  head = "Cabeza",
  shoulder = "Hombro",
  arm = "Brazo/mano",
  chest = "Pecho",
  back = "Espalda",
  abdomen = "Abdomen",
  groin = "Cadera/ingle",
  thigh = "Muslo",
  hamstring = "Isquios",
  knee = "Rodilla",
  calf = "Gemelo/tibia",
  ankle = "Tobillo",
  foot = "Pie",
  illness = "Enfermedad/estado físico",
  other = "Otras"
)

zone_to_label <- function(z) {
  lab <- unname(zone_labels[z])
  ifelse(is.na(lab), str_to_title(z), lab)
}

# -------------------------
# Carga y preparación de datos
# -------------------------
data_files <- c("estadisticas2.xlsx", "num_eventos.json", "Transfermarkt_2324.json", "lesiones.json", "bodymap2.png")
missing_files <- data_files[!file.exists(data_files)]
if (length(missing_files) > 0) {
  stop("Faltan archivos en la carpeta de la app: ", paste(missing_files, collapse = ", "))
}

estadisticas <- read_excel("estadisticas2.xlsx") %>%
  as_tibble() %>%
  mutate(
    player_id = fmt_id(player_id),
    posicion_evento = as.character(posicion_evento),
    squad_stats = as.character(`Equipo durante el período seleccionado`),
    across(all_of(metric_cols), ~ suppressWarnings(as.numeric(.x)))
  )

eventos <- read_json("num_eventos.json", simplifyVector = TRUE) %>%
  as_tibble()

if ("location" %in% names(eventos)) {
  loc <- eventos$location
  if (is.matrix(loc) || is.data.frame(loc)) {
    eventos$x <- suppressWarnings(as.numeric(loc[[1]]))
    eventos$y <- suppressWarnings(as.numeric(loc[[2]]))
  } else {
    eventos$x <- map_dbl(loc, function(z) {
      if (is.null(z) || length(z) < 1) return(NA_real_)
      suppressWarnings(as.numeric(z[[1]]))
    })
    eventos$y <- map_dbl(loc, function(z) {
      if (is.null(z) || length(z) < 2) return(NA_real_)
      suppressWarnings(as.numeric(z[[2]]))
    })
  }
} else {
  eventos$x <- NA_real_
  eventos$y <- NA_real_
}

eventos <- eventos %>%
  mutate(
    player_id = fmt_id(player_id),
    game_date = suppressWarnings(ymd_hms(game_date, quiet = TRUE)),
    event_name = as.character(event_name),
    sector = as.character(sector),
    player_name = as.character(player_name),
    team_name = as.character(team_name),
    outcome_lbl = case_when(
      as.character(outcome) == "1" ~ "Exitosa",
      as.character(outcome) == "0" ~ "No exitosa",
      TRUE ~ "Sin resultado"
    ),
    sector_en_posicion = to_bool(sector_en_posicion),
    sector_en_vecino = to_bool(sector_en_vecino),
    evento_en_valido = to_bool(evento_en_valido)
  )

Transfermarkt_2324 <- read_json("Transfermarkt_2324.json", simplifyVector = TRUE) %>%
  as_tibble() %>%
  mutate(
    player_id = fmt_id(player_id),
    birthday = suppressWarnings(ymd(birthday)),
    edad_2024 = floor(time_length(interval(birthday, ymd("2024-06-30")), "years"))
  )

lesiones_raw <- read_json("lesiones.json", simplifyVector = FALSE)
Transfermarkt_2324$lesiones <- lesiones_raw

img <- readPNG("bodymap2.png")
body_height <- dim(img)[1]
body_width <- dim(img)[2]

jugadores <- Transfermarkt_2324 %>%
  select(player_name, player_id, squad, birthday, edad_2024, player_url) %>%
  arrange(player_name)

display_name_lookup <- setNames(jugadores$player_name, jugadores$player_id)

# Estadísticas en percentiles por posición
estadisticas_percentiles <- estadisticas %>%
  group_by(posicion_evento) %>%
  mutate(
    across(
      all_of(metric_cols),
      ~ percent_rank(.x) * 100,
      .names = "{.col}_pct"
    )
  ) %>%
  ungroup()

estadisticas_pct_long <- estadisticas_percentiles %>%
  pivot_longer(
    cols = all_of(paste0(metric_cols, "_pct")),
    names_to = "metric",
    values_to = "percentil"
  ) %>%
  mutate(
    metric = str_remove(metric, "_pct$"),
    label = unname(metric_labels[metric]),
    group = unname(metric_group_lookup[metric])
  )

stats_resumen_jugador <- estadisticas_pct_long %>%
  group_by(player_id, Jugador) %>%
  summarise(
    posiciones = paste(sort(unique(posicion_evento)), collapse = ", "),
    percentil_medio = mean(percentil, na.rm = TRUE),
    .groups = "drop"
  )

# Resumen de eventos por jugador
shooting_events <- c("Attempt Saved", "Miss", "Post", "Goal", "Chance missed")

eventos_resumen_jugador <- eventos %>%
  group_by(player_id) %>%
  summarise(
    player_name_eventos = first_not_na(player_name),
    team_name_eventos = first_not_na(team_name),
    total_eventos = n(),
    partidos = n_distinct(game_id),
    pct_sector_posicion = safe_pct(sector_en_posicion),
    pct_sector_vecino = safe_pct(sector_en_vecino),
    pct_evento_valido = safe_pct(evento_en_valido),
    pases = sum(event_name == "Pass", na.rm = TRUE),
    tiros = sum(event_name %in% shooting_events, na.rm = TRUE),
    goles = sum(event_name == "Goal", na.rm = TRUE),
    asistencias = sum(event_name == "Assist", na.rm = TRUE),
    .groups = "drop"
  )

team_events <- eventos %>%
  count(team_name, name = "eventos", sort = TRUE) %>%
  filter(!is.na(team_name), team_name != "")

# Lesiones en formato largo
lesiones_long <- imap_dfr(lesiones_raw, function(injuries, idx) {
  if (length(injuries) == 0) return(tibble())
  bind_rows(injuries) %>%
    mutate(
      player_id = Transfermarkt_2324$player_id[idx],
      player_name = Transfermarkt_2324$player_name[idx],
      squad = Transfermarkt_2324$squad[idx]
    )
})

if (nrow(lesiones_long) > 0) {
  lesiones_long <- lesiones_long %>%
    mutate(
      duration_days = parse_number_safe(duration),
      games_missed = suppressWarnings(as.numeric(games_missed)),
      date_from = suppressWarnings(dmy(date_from)),
      date_until = suppressWarnings(dmy(date_until)),
      zone = injury_to_zone(injury),
      zone_label = zone_to_label(zone),
      severity = case_when(
        is.na(duration_days) ~ "Sin dato",
        duration_days <= 7 ~ "Leve (≤7 días)",
        duration_days <= 28 ~ "Moderada (8-28)",
        duration_days <= 90 ~ "Grave (29-90)",
        TRUE ~ "Muy grave (>90)"
      ),
      severity = factor(
        severity,
        levels = c("Leve (≤7 días)", "Moderada (8-28)", "Grave (29-90)", "Muy grave (>90)", "Sin dato")
      )
    )
}

lesiones_resumen_jugador <- lesiones_long %>%
  group_by(player_id) %>%
  summarise(
    total_lesiones = n(),
    dias_baja = sum(duration_days, na.rm = TRUE),
    partidos_perdidos = sum(games_missed, na.rm = TRUE),
    ultima_lesion = if (all(is.na(date_from))) as.Date(NA) else max(date_from, na.rm = TRUE),
    zona_mas_frecuente = names(sort(table(zone_label), decreasing = TRUE))[1],
    .groups = "drop"
  )

team_injuries <- lesiones_long %>%
  group_by(squad) %>%
  summarise(
    lesiones = n(),
    dias_baja = sum(duration_days, na.rm = TRUE),
    jugadores_con_lesion = n_distinct(player_id),
    .groups = "drop"
  ) %>%
  arrange(desc(dias_baja))

data_explorer <- jugadores %>%
  left_join(stats_resumen_jugador %>% select(player_id, posiciones, percentil_medio), by = "player_id") %>%
  left_join(eventos_resumen_jugador %>% select(player_id, total_eventos, partidos, pct_evento_valido, pct_sector_posicion, goles, asistencias), by = "player_id") %>%
  left_join(lesiones_resumen_jugador %>% select(player_id, total_lesiones, dias_baja, partidos_perdidos), by = "player_id") %>%
  mutate(
    across(c(total_eventos, partidos, goles, asistencias, total_lesiones, dias_baja, partidos_perdidos), ~ replace_na(.x, 0)),
    percentil_medio = replace_na(percentil_medio, NA_real_)
  )

# -------------------------
# Campo y sectores
# -------------------------
field_length <- 100
field_width <- 100
n_cols <- 4
n_rows <- 5
col_width <- field_length / n_cols
row_height <- field_width / n_rows

sectors <- expand.grid(col = 1:n_cols, row = 1:n_rows)
sectors$xmin <- (sectors$col - 1) * col_width
sectors$xmax <- sectors$col * col_width
sectors$ymin <- (sectors$row - 1) * row_height
sectors$ymax <- sectors$row * row_height
sectors <- sectors[order(sectors$col, sectors$row), ]
sectors$cell <- paste0("C", seq_len(nrow(sectors)))
sectors$xcenter <- (sectors$xmin + sectors$xmax) / 2
sectors$ycenter <- (sectors$ymin + sectors$ymax) / 2

# -------------------------
# Polígonos del bodymap
# Coordenadas escaladas desde el trazado original a la imagen usada.
# -------------------------
body_polygons_raw <- bind_rows(
  tibble(zone="head", x=c(280, 295, 320, 350, 375, 380, 330, 310, 275), y=c(120, 20, 15, 20, 120, 170, 280, 280, 170), group="head_front"),
  tibble(zone="shoulder", x=c(355, 400, 440, 480, 420, 390, 255, 220, 180, 200, 270, 295, 325), y=c(250, 340, 340, 430, 500, 400, 400, 490, 430, 350, 330, 250, 290), group="shoulder_front"),
  tibble(zone="arm", x=c(200, 130, 40, 0, 35, 140, 220, 255), y=c(360, 520, 760, 920, 980, 780, 520, 400), group="arm_front_left"),
  tibble(zone="arm", x=c(420, 500, 610, 680, 650, 540, 450, 390), y=c(400, 520, 760, 920, 980, 780, 520, 400), group="arm_front_right"),
  tibble(zone="chest", x=c(390, 420, 420, 410, 325, 245, 230, 220, 260), y=c(400, 470, 520, 835, 670, 835, 520, 480, 400), group="chest_front"),
  tibble(zone="abdomen", x=c(410, 325, 245, 290, 370), y=c(835, 670, 840, 940, 940), group="abdomen_front"),
  tibble(zone="groin", x=c(410, 370, 290, 230, 225, 420), y=c(835, 940, 940, 840, 1050, 1050), group="groin_front"),
  tibble(zone="thigh", x=c(225, 225, 255, 280, 320, 330, 340, 360, 400, 420, 420), y=c(1050, 1200, 1350, 1370, 1355, 1150, 1370, 1360, 1350, 1220, 1050), group="thigh_front"),
  tibble(zone="knee", x=c(250, 250, 280, 320, 320, 280), y=c(1340, 1520, 1470, 1520, 1355, 1370), group="knee_front_left"),
  tibble(zone="knee", x=c(340, 340, 360, 400, 400, 370), y=c(1370, 1490, 1470, 1490, 1345, 1360), group="knee_front_right"),
  tibble(zone="calf", x=c(250, 265, 300, 320, 320, 310, 280), y=c(1500, 1830, 1830, 1600, 1650, 1500, 1480), group="calf_front_left"),
  tibble(zone="calf", x=c(340, 330, 340, 340, 380, 400, 370), y=c(1490, 1600, 1650, 1830, 1830, 1490, 1470), group="calf_front_right"),
  tibble(zone="ankle", x=c(265, 300, 310, 265), y=c(1830, 1830, 1880, 1880), group="ankle_front_left"),
  tibble(zone="ankle", x=c(345, 380, 380, 340), y=c(1830, 1830, 1880, 1890), group="ankle_front_right"),
  tibble(zone="foot", x=c(310, 310, 270, 220, 240, 260), y=c(1880, 1940, 2030, 2030, 1940, 1880), group="foot_front_left"),
  tibble(zone="foot", x=c(380, 405, 440, 375, 330, 340), y=c(1880, 1925, 2030, 2030, 1940, 1880), group="foot_front_right"),
  tibble(zone="head", x=c(1010, 1020, 1050, 1080, 1100, 1110, 1070, 1010, 1000), y=c(120, 20, 15, 20, 110, 180, 250, 210, 180), group="head_back"),
  tibble(zone="arm", x=c(910, 850, 770, 740, 780, 880, 940, 970), y=c(350, 520, 760, 920, 980, 780, 560, 400), group="arm_back_left"),
  tibble(zone="arm", x=c(1180, 1250, 1330, 1360, 1320, 1230, 1150, 1120), y=c(400, 520, 760, 920, 980, 780, 560, 400), group="arm_back_right"),
  tibble(zone="back", x=c(1020, 1070, 1090, 1100, 1180, 1200, 1150, 1130, 1100, 1050, 1020, 980, 960, 970, 910, 940, 1000), y=c(230, 240, 230, 320, 360, 490, 550, 850, 840, 920, 840, 850, 560, 550, 510, 350, 320), group="back"),
  tibble(zone="groin", x=c(1050, 1020, 980, 960, 1010, 1050, 1100, 1150, 1130, 1100), y=c(920, 840, 850, 1050, 1100, 1060, 1080, 1010, 850, 850), group="groin_back"),
  tibble(zone="hamstring", x=c(1010, 960, 970, 980, 1050, 1060, 1070, 1125, 1155, 1100, 1050), y=c(1100, 1060, 1300, 1500, 1500, 1150, 1500, 1490, 1020, 1080, 1050), group="hamstring_back"),
  tibble(zone="calf", x=c(1050, 980, 975, 980, 1000, 1040, 1050, 1055, 1050), y=c(1500, 1500, 1550, 1620, 1890, 1890, 1700, 1670, 1500), group="calf_back"),
  tibble(zone="calf", x=c(1125, 1070, 1070, 1060, 1070, 1070, 1110, 1135), y=c(1490, 1500, 1550, 1580, 1610, 1880, 1870, 1570), group="calf_back_right"),
  tibble(zone="ankle", x=c(1040, 1000, 990, 1045), y=c(1890, 1890, 1950, 1965), group="ankle_back"),
  tibble(zone="ankle", x=c(1070, 1060, 1110, 1110), y=c(1880, 1965, 1920, 1880), group="ankle_back_right"),
  tibble(zone="foot", x=c(1000, 990, 950, 955, 1050, 1050), y=c(1950, 1920, 1910, 1980, 2040, 1950), group="foot_back"),
  tibble(zone="foot", x=c(1060, 1070, 1170, 1170, 1110), y=c(1965, 2030, 1990, 1950, 1920), group="foot_back_right")
)

body_polygons <- body_polygons_raw %>%
  mutate(
    x = x / 1365 * body_width,
    y = y / 2048 * body_height
  )

# -------------------------
# Funciones de gráficos
# -------------------------
get_player_stats_summary <- function(pid, pos = NULL, group_filter = "Todas") {
  df <- estadisticas_pct_long %>% filter(.data$player_id == pid)
  if (!is.null(pos) && !identical(pos, "__all__")) df <- df %>% filter(.data$posicion_evento == pos)
  if (!is.null(group_filter) && group_filter != "Todas") df <- df %>% filter(.data$group == group_filter)
  df %>%
    group_by(metric, label, group) %>%
    summarise(percentil = mean(percentil, na.rm = TRUE), .groups = "drop") %>%
    filter(!is.na(percentil))
}

plot_percentile_profile <- function(pid, pos = NULL, group_filter = "Todas") {
  df <- get_player_stats_summary(pid, pos, group_filter)
  if (nrow(df) == 0) return(empty_plot("Sin estadísticas Wyscout para este filtro"))
  df <- df %>%
    arrange(percentil) %>%
    mutate(label = factor(label, levels = label))
  ggplot(df, aes(x = label, y = percentil, fill = group)) +
    geom_col(width = 0.72, alpha = 0.9) +
    geom_text(aes(label = round(percentil, 0)), hjust = -0.15, size = 3.7, fontface = "bold") +
    coord_flip() +
    scale_y_continuous(limits = c(0, 108), breaks = seq(0, 100, 25), labels = function(x) paste0(x, "%")) +
    labs(x = NULL, y = "Percentil dentro de su posición", fill = "Grupo") +
    theme_minimal(base_size = 13) +
    theme(
      legend.position = "bottom",
      panel.grid.major.y = element_blank(),
      axis.text.y = element_text(face = "bold")
    )
}


get_strengths_weaknesses <- function(pid, pos = NULL, group_filter = "Todas") {
  df <- get_player_stats_summary(pid, pos, group_filter)
  if (nrow(df) == 0) return(tibble(tipo = "Sin datos", grupo = "", metrica = "", percentil = NA_real_))
  n_take <- min(5, nrow(df))
  bind_rows(
    df %>% slice_max(percentil, n = n_take, with_ties = FALSE) %>% mutate(tipo = "Fortaleza"),
    df %>% slice_min(percentil, n = n_take, with_ties = FALSE) %>% mutate(tipo = "Área de mejora")
  ) %>%
    transmute(tipo, grupo = group, metrica = label, percentil = round(percentil, 1))
}

plot_metric_ranking <- function(metric, pos, pid) {
  if (is.null(metric) || is.na(metric) || is.null(pos) || is.na(pos)) return(empty_plot("Selecciona una métrica y una posición"))
  pct_col <- paste0(metric, "_pct")
  if (!pct_col %in% names(estadisticas_percentiles)) return(empty_plot("Métrica no disponible"))
  df <- estadisticas_percentiles %>%
    filter(.data$posicion_evento == pos) %>%
    mutate(valor_pct = .data[[pct_col]]) %>%
    arrange(desc(valor_pct)) %>%
    slice_head(n = 18) %>%
    mutate(
      es_jugador = player_id == pid,
      Jugador = factor(Jugador, levels = rev(Jugador))
    )
  if (nrow(df) == 0) return(empty_plot("Sin ranking para esta posición"))
  ggplot(df, aes(x = Jugador, y = valor_pct, fill = es_jugador)) +
    geom_col(width = 0.72) +
    geom_text(aes(label = round(valor_pct, 0)), hjust = -0.15, size = 3.2) +
    coord_flip() +
    scale_y_continuous(limits = c(0, 108), labels = function(x) paste0(x, "%")) +
    scale_fill_manual(values = c("TRUE" = "#0B3D2E", "FALSE" = "#91A8A0"), guide = "none") +
    labs(x = NULL, y = "Percentil", title = paste0(unname(metric_labels[metric]), " - ", pos)) +
    theme_minimal(base_size = 13) +
    theme(panel.grid.major.y = element_blank(), plot.title = element_text(face = "bold", hjust = 0.5))
}


# Radar radial basado en la función original del trabajo.
# Se mantiene la idea de barras en coordenadas polares, pero se añaden
# nombres legibles, facetas por posición y filtros por grupo.
graficar_percentil <- function(jugador_id, pos = NULL, group_filter = "Todas") {
  df <- estadisticas_pct_long %>%
    filter(player_id == jugador_id)

  if (!is.null(pos) && !identical(pos, "__all__")) df <- df %>% filter(posicion_evento == pos)
  if (!is.null(group_filter) && group_filter != "Todas") df <- df %>% filter(group == group_filter)

  df <- df %>%
    group_by(posicion_evento, metric, label, group) %>%
    summarise(percentil = mean(percentil, na.rm = TRUE), .groups = "drop") %>%
    filter(!is.na(percentil)) %>%
    mutate(
      label = factor(label, levels = unname(metric_labels[metric_cols])),
      posicion_evento = factor(posicion_evento, levels = sort(unique(posicion_evento)))
    )

  if (nrow(df) == 0) return(empty_plot("Sin percentiles para este jugador"))

  ggplot(df, aes(x = label, y = percentil, fill = group)) +
    geom_col(width = 0.82, colour = "white", linewidth = 0.35, alpha = 0.88) +
    coord_polar() +
    geom_hline(yintercept = c(25, 50, 75, 100), colour = "grey70", linetype = "dashed", linewidth = 0.35) +
    scale_y_continuous(limits = c(0, 100), breaks = c(25, 50, 75, 100), expand = c(0, 0)) +
    facet_wrap(~ posicion_evento, ncol = 2) +
    labs(x = NULL, y = NULL, fill = "Grupo") +
    theme_minimal(base_size = 12) +
    theme(
      legend.position = "bottom",
      axis.text.y = element_blank(),
      axis.ticks = element_blank(),
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      strip.text = element_text(face = "bold", size = 12),
      axis.text.x = element_text(size = 9, face = "bold")
    )
}

graficar_percentil_comp <- function(jugadores_ids, pos = "__all__", group_filter = "Todas") {
  ids <- unique(jugadores_ids[!is.na(jugadores_ids) & jugadores_ids != ""])
  if (length(ids) < 2) return(empty_plot("Añade al menos un jugador para comparar"))

  df <- estadisticas_pct_long %>% filter(player_id %in% ids)
  if (!is.null(group_filter) && group_filter != "Todas") df <- df %>% filter(group == group_filter)

  if (!is.null(pos) && pos != "__all__") {
    df <- df %>% filter(posicion_evento == pos)
  } else {
    posiciones_comunes <- df %>%
      group_by(posicion_evento) %>%
      summarise(n_jug = n_distinct(player_id), .groups = "drop") %>%
      filter(n_jug == length(ids)) %>%
      pull(posicion_evento)

    if (length(posiciones_comunes) == 0) {
      return(empty_plot("No hay posiciones comunes entre los jugadores seleccionados"))
    }
    df <- df %>% filter(posicion_evento %in% posiciones_comunes)
  }

  if (nrow(df) == 0) return(empty_plot("Sin datos para la comparación seleccionada"))

  name_order <- jugadores$player_name[match(ids, jugadores$player_id)]
  name_order[is.na(name_order)] <- ids[is.na(name_order)]

  df <- df %>%
    group_by(posicion_evento, player_id, Jugador, metric, label, group) %>%
    summarise(percentil = mean(percentil, na.rm = TRUE), .groups = "drop") %>%
    filter(!is.na(percentil)) %>%
    mutate(
      Jugador_display = unname(display_name_lookup[player_id]),
      Jugador_display = ifelse(is.na(Jugador_display), Jugador, Jugador_display),
      Jugador_display = factor(Jugador_display, levels = name_order),
      label = factor(label, levels = unname(metric_labels[metric_cols])),
      posicion_evento = factor(posicion_evento, levels = sort(unique(posicion_evento)))
    )

  ggplot(df, aes(x = label, y = percentil, fill = Jugador_display)) +
    geom_col(position = position_dodge(width = 0.82), width = 0.78, colour = "white", linewidth = 0.25, alpha = 0.84) +
    coord_polar() +
    geom_hline(yintercept = c(25, 50, 75, 100), colour = "grey70", linetype = "dashed", linewidth = 0.35) +
    scale_y_continuous(limits = c(0, 100), breaks = c(25, 50, 75, 100), expand = c(0, 0)) +
    facet_wrap(~ posicion_evento, ncol = 2) +
    labs(x = NULL, y = NULL, fill = "Jugador") +
    theme_minimal(base_size = 12) +
    theme(
      legend.position = "bottom",
      axis.text.y = element_blank(),
      axis.ticks = element_blank(),
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      strip.text = element_text(face = "bold", size = 12),
      axis.text.x = element_text(size = 9, face = "bold")
    )
}


plot_event_pitch <- function(pid, datos_jugador, show_zones = TRUE) {
  sectors_plot <- sectors
  sectors_plot$cell <- as.character(sectors_plot$cell)
  sectors_plot$zona <- "normal"

  if (show_zones && nrow(datos_jugador) > 0) {
    sectores_jugador <- unique(datos_jugador$sector[datos_jugador$sector_en_posicion])
    sectores_vecinos <- unique(datos_jugador$sector[datos_jugador$sector_en_vecino])
    sectors_plot$zona[sectors_plot$cell %in% sectores_jugador] <- "zona natural"
    sectores_vecinos <- setdiff(sectores_vecinos, sectors_plot$cell[sectors_plot$zona == "zona natural"])
    sectors_plot$zona[sectors_plot$cell %in% sectores_vecinos] <- "zona vecina"
  }

  sectors_plot$tooltip <- paste0("Sector: ", sectors_plot$cell, "<br>Tipo: ", sectors_plot$zona)

  coords <- datos_jugador %>%
    filter(!is.na(x), !is.na(y), x >= 0, x <= 100, y >= 0, y <= 100) %>%
    mutate(
      id = paste0(event_id %||% row_number(), "_", row_number()),
      tooltip = paste0(
        "Evento: ", event_name,
        "<br>Resultado: ", outcome_lbl,
        "<br>Sector: ", sector,
        "<br>Minuto: ", min, "'", sec, "''",
        "<br>Partido: ", home_team, " vs ", away_team
      )
    )

  colores_zona <- c("normal" = "#2E8B57", "zona vecina" = "#4CAF50", "zona natural" = "#124A2F")

  p <- ggplot() +
    geom_rect_interactive(
      data = sectors_plot,
      aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = zona, tooltip = tooltip, data_id = cell),
      color = "white", linewidth = 0.7
    ) +
    scale_fill_manual(values = colores_zona, guide = "none") +
    geom_text(data = sectors_plot, aes(x = xcenter, y = ycenter, label = cell), colour = "white", size = 4, fontface = "bold") +
    coord_fixed(xlim = c(0, field_length), ylim = c(0, field_width), expand = FALSE) +
    labs(x = "Largo del campo", y = "Ancho del campo") +
    theme_minimal(base_size = 13) +
    theme(
      panel.background = element_rect(fill = "#2E8B57", colour = NA),
      plot.background = element_rect(fill = "#2E8B57", colour = NA),
      panel.grid.major = element_line(colour = "white", linetype = "dashed", linewidth = 0.25),
      panel.grid.minor = element_blank(),
      axis.title = element_text(colour = "white", face = "bold"),
      axis.text = element_text(colour = "white"),
      legend.position = "none"
    )

  if (nrow(coords) > 0) {
    p <- p +
      geom_point_interactive(
        data = coords,
        aes(x = x, y = y, colour = event_name, tooltip = tooltip, data_id = id),
        size = 1.8, alpha = 0.8
      ) +
      guides(colour = "none")
  }

  girafe(
    ggobj = p,
    width_svg = 8,
    height_svg = 6,
    options = list(
      opts_hover(css = "stroke:black;stroke-width:2px;opacity:1;"),
      opts_tooltip(css = "background-color:white;color:#222;padding:8px;border-radius:6px;box-shadow:0 2px 10px rgba(0,0,0,.2);")
    )
  )
}

plot_sector_heatmap <- function(datos_jugador) {
  df <- datos_jugador %>%
    filter(sector %in% sectors$cell) %>%
    count(sector, name = "n")

  sectors_plot <- sectors %>%
    left_join(df, by = c("cell" = "sector")) %>%
    mutate(
      n = replace_na(n, 0),
      pct = ifelse(sum(n) > 0, n / sum(n) * 100, 0),
      tooltip = paste0("Sector: ", cell, "<br>Eventos: ", n, "<br>Peso: ", round(pct, 1), "%")
    )

  p <- ggplot(sectors_plot) +
    geom_rect_interactive(
      aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = n, tooltip = tooltip, data_id = cell),
      color = "white", linewidth = 0.8
    ) +
    geom_text(aes(x = xcenter, y = ycenter, label = paste0(cell, "\n", n)), colour = "white", fontface = "bold", size = 4) +
    scale_fill_gradient(low = "#B7D7C2", high = "#053B24", labels = comma) +
    coord_fixed(xlim = c(0, 100), ylim = c(0, 100), expand = FALSE) +
    labs(x = NULL, y = NULL, fill = "Eventos") +
    theme_minimal(base_size = 13) +
    theme(
      panel.background = element_rect(fill = "#2E8B57", colour = NA),
      plot.background = element_rect(fill = "#2E8B57", colour = NA),
      panel.grid = element_blank(),
      axis.text = element_blank(),
      legend.position = "bottom"
    )

  girafe(ggobj = p, width_svg = 8, height_svg = 6)
}

plot_top_events <- function(df, n = 12) {
  if (nrow(df) == 0) return(empty_plot("Sin eventos para los filtros seleccionados"))
  top <- df %>%
    count(event_name, sort = TRUE) %>%
    slice_head(n = n) %>%
    mutate(event_name = factor(event_name, levels = rev(event_name)))
  ggplot(top, aes(x = event_name, y = n)) +
    geom_col(fill = "#0B3D2E", alpha = 0.9) +
    geom_text(aes(label = n), hjust = -0.15, size = 3.5, fontface = "bold") +
    coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.14))) +
    labs(x = NULL, y = "Número de eventos") +
    theme_minimal(base_size = 13) +
    theme(panel.grid.major.y = element_blank(), axis.text.y = element_text(face = "bold"))
}

plot_event_timeline <- function(df) {
  if (nrow(df) == 0 || all(is.na(df$game_date))) return(empty_plot("Sin fechas de partido"))
  partidos <- df %>%
    filter(!is.na(game_date)) %>%
    group_by(game_id, fecha = as.Date(game_date), partido = paste(first_not_na(home_team), first_not_na(away_team), sep = " vs ")) %>%
    summarise(eventos = n(), .groups = "drop") %>%
    arrange(fecha)
  if (nrow(partidos) < 2) return(empty_plot("Se necesita más de un partido para la evolución"))
  ggplot(partidos, aes(x = fecha, y = eventos, group = 1)) +
    geom_line(linewidth = 1.1, colour = "#0B3D2E") +
    geom_point(size = 2.6, colour = "#0B3D2E") +
    geom_smooth(se = FALSE, linewidth = 0.7, linetype = "dashed", colour = "grey40") +
    labs(x = "Fecha", y = "Eventos") +
    theme_minimal(base_size = 13) +
    theme(panel.grid.minor = element_blank())
}

plot_injury_donut_df <- function(df) {
  if (nrow(df) == 0) return(empty_plot("Sin lesiones registradas"))
  resumen <- df %>%
    count(zone_label, name = "n") %>%
    mutate(
      pct = n / sum(n),
      ypos = cumsum(pct) - pct / 2,
      label = ifelse(pct >= 0.06, paste0(round(pct * 100, 0), "%"), "")
    )
  ggplot(resumen, aes(x = 2, y = pct, fill = zone_label)) +
    geom_col(color = "white", linewidth = 0.5) +
    geom_label(aes(y = ypos, label = label), size = 3.5, fill = "white", label.size = 0.15, fontface = "bold") +
    coord_polar(theta = "y") +
    xlim(0.5, 2.5) +
    labs(fill = "Zona") +
    theme_void(base_size = 13) +
    theme(legend.position = "right", legend.title = element_text(face = "bold"))
}

plot_injury_fillmap_df <- function(df, value = "duration_days") {
  body_zones <- unique(body_polygons$zone)
  df <- df %>% filter(zone %in% body_zones)
  if (nrow(df) == 0) return(empty_plot("Sin lesiones corporales para colorear"))

  metric_label <- c(count = "Nº lesiones", duration_days = "Días de baja", games_missed = "Partidos perdidos")
  if (value == "count") {
    df$.metric <- 1
  } else if (value %in% names(df)) {
    df$.metric <- suppressWarnings(as.numeric(df[[value]]))
  } else {
    df$.metric <- 1
  }

  summary_df <- df %>%
    group_by(zone) %>%
    summarise(metric = sum(.metric, na.rm = TRUE), lesiones = n(), .groups = "drop")

  poly_df <- body_polygons %>%
    left_join(summary_df, by = "zone") %>%
    mutate(metric = replace_na(metric, 0))

  ggplot() +
    annotation_custom(
      grid::rasterGrob(img, width = grid::unit(1, "npc"), height = grid::unit(1, "npc"), interpolate = TRUE),
      xmin = 0, xmax = body_width, ymin = 0, ymax = body_height
    ) +
    geom_polygon(
      data = poly_df,
      aes(x = x, y = body_height - y, group = group, fill = metric),
      alpha = 0.65,
      colour = NA
    ) +
    scale_fill_gradient(low = "#FFF5F5", high = "#8B0000", labels = comma) +
    coord_fixed(xlim = c(0, body_width), ylim = c(0, body_height), expand = FALSE) +
    labs(fill = first_or(metric_label[value], "Métrica")) +
    theme_void(base_size = 13) +
    theme(legend.position = "bottom", legend.title = element_text(face = "bold"))
}

plot_injury_seasons_df <- function(df) {
  if (nrow(df) == 0) return(empty_plot("Sin lesiones registradas"))
  season_levels <- sort(unique(lesiones_long$season_injured))
  resumen <- df %>%
    filter(!is.na(season_injured)) %>%
    group_by(season_injured) %>%
    summarise(lesiones = n(), dias = sum(duration_days, na.rm = TRUE), .groups = "drop") %>%
    mutate(season_injured = factor(season_injured, levels = season_levels))
  if (nrow(resumen) == 0) return(empty_plot("Sin temporada registrada"))
  ggplot(resumen, aes(x = season_injured, y = dias)) +
    geom_col(fill = "#8B0000", alpha = 0.85) +
    geom_text(aes(label = paste0(lesiones, " les.")), vjust = -0.25, size = 3.2, fontface = "bold") +
    scale_y_continuous(expand = expansion(mult = c(0, 0.16))) +
    labs(x = "Temporada", y = "Días de baja") +
    theme_minimal(base_size = 13) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1), panel.grid.major.x = element_blank())
}

plot_injury_severity_df <- function(df) {
  if (nrow(df) == 0) return(empty_plot("Sin lesiones registradas"))
  resumen <- df %>% count(severity, name = "n") %>% filter(!is.na(severity))
  ggplot(resumen, aes(x = severity, y = n)) +
    geom_col(fill = "#C0392B", alpha = 0.85) +
    geom_text(aes(label = n), vjust = -0.25, fontface = "bold") +
    scale_y_continuous(expand = expansion(mult = c(0, 0.14))) +
    labs(x = NULL, y = "Lesiones") +
    theme_minimal(base_size = 13) +
    theme(axis.text.x = element_text(angle = 25, hjust = 1), panel.grid.major.x = element_blank())
}

plot_compare_heatmap <- function(ids, pos = "__all__", group_filter = "Todas") {
  if (length(ids) < 2) return(empty_plot("Añade al menos un jugador en el comparador"))
  df <- estadisticas_pct_long %>% filter(player_id %in% ids)
  if (!is.null(pos) && pos != "__all__") df <- df %>% filter(posicion_evento == pos)
  if (!is.null(group_filter) && group_filter != "Todas") df <- df %>% filter(group == group_filter)
  if (nrow(df) == 0) return(empty_plot("No hay posición común para los jugadores elegidos"))

  name_order <- jugadores$player_name[match(ids, jugadores$player_id)]
  name_order[is.na(name_order)] <- ids[is.na(name_order)]

  df <- df %>%
    group_by(player_id, Jugador, metric, label, group) %>%
    summarise(percentil = mean(percentil, na.rm = TRUE), .groups = "drop") %>%
    mutate(
      Jugador_display = unname(display_name_lookup[player_id]),
      Jugador_display = ifelse(is.na(Jugador_display), Jugador, Jugador_display),
      Jugador_display = factor(Jugador_display, levels = name_order),
      label = factor(label, levels = unname(metric_labels[metric_cols]))
    )

  ggplot(df, aes(x = label, y = Jugador_display, fill = percentil)) +
    geom_tile(color = "white", linewidth = 0.7) +
    geom_text(aes(label = round(percentil, 0)), size = 3.2, fontface = "bold") +
    scale_fill_gradient(low = "#F7FCF5", high = "#0B3D2E", limits = c(0, 100), labels = function(x) paste0(x, "%")) +
    labs(x = NULL, y = NULL, fill = "Percentil") +
    theme_minimal(base_size = 13) +
    theme(axis.text.x = element_text(angle = 35, hjust = 1), panel.grid = element_blank(), axis.text.y = element_text(face = "bold"))
}

plot_compare_metric <- function(ids, metric, pos = "__all__") {
  if (length(ids) < 2) return(empty_plot("Añade al menos un jugador en el comparador"))
  df <- estadisticas %>% filter(player_id %in% ids)
  if (!is.null(pos) && pos != "__all__") df <- df %>% filter(posicion_evento == pos)
  if (nrow(df) == 0 || is.null(metric)) return(empty_plot("No hay datos para la comparación"))

  name_order <- jugadores$player_name[match(ids, jugadores$player_id)]
  name_order[is.na(name_order)] <- ids[is.na(name_order)]

  df <- df %>%
    group_by(player_id, Jugador) %>%
    summarise(valor = mean(.data[[metric]], na.rm = TRUE), .groups = "drop") %>%
    mutate(
      Jugador_display = unname(display_name_lookup[player_id]),
      Jugador_display = ifelse(is.na(Jugador_display), Jugador, Jugador_display),
      Jugador_display = factor(Jugador_display, levels = rev(name_order))
    )

  ggplot(df, aes(x = Jugador_display, y = valor)) +
    geom_col(fill = "#0B3D2E", alpha = 0.9) +
    geom_text(aes(label = round(valor, 2)), hjust = -0.15, fontface = "bold", size = 3.4) +
    coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.14))) +
    labs(x = NULL, y = unname(metric_labels[metric])) +
    theme_minimal(base_size = 13) +
    theme(panel.grid.major.y = element_blank(), axis.text.y = element_text(face = "bold"))
}

calculate_similar_players <- function(pid, pos = "__all__", n = 10) {
  positions <- estadisticas_percentiles %>% filter(player_id == pid) %>% pull(posicion_evento) %>% unique()
  if (length(positions) == 0) return(tibble())
  ref_pos <- if (!is.null(pos) && pos != "__all__" && pos %in% positions) pos else positions[1]
  pct_cols <- paste0(metric_cols, "_pct")
  ref <- estadisticas_percentiles %>% filter(player_id == pid, posicion_evento == ref_pos) %>% slice(1)
  candidates <- estadisticas_percentiles %>% filter(posicion_evento == ref_pos, player_id != pid)
  if (nrow(ref) == 0 || nrow(candidates) == 0) return(tibble())

  ref_vec <- as.numeric(ref[1, pct_cols])
  ref_vec[is.na(ref_vec)] <- 50
  mat <- as.matrix(candidates[, pct_cols])
  mat[is.na(mat)] <- 50
  distance <- sqrt(rowSums((sweep(mat, 2, ref_vec, FUN = "-"))^2))
  maxd <- max(distance, na.rm = TRUE)
  similarity <- if (is.finite(maxd) && maxd > 0) 100 * (1 - distance / maxd) else rep(100, length(distance))

  candidates %>%
    mutate(
      distancia = distance,
      similitud = similarity,
      Jugador_display = unname(display_name_lookup[player_id]),
      Jugador_display = ifelse(is.na(Jugador_display), Jugador, Jugador_display)
    ) %>%
    arrange(distancia) %>%
    transmute(
      Jugador = Jugador_display,
      player_id,
      Equipo = squad_stats,
      Posición = posicion_evento,
      Similitud = round(similitud, 1),
      Distancia = round(distancia, 1)
    ) %>%
    slice_head(n = n)
}

plot_team_injuries <- function() {
  df <- team_injuries %>% slice_max(dias_baja, n = 15) %>% mutate(squad = factor(squad, levels = rev(squad)))
  if (nrow(df) == 0) return(empty_plot("Sin datos de lesiones por equipo"))
  ggplot(df, aes(x = squad, y = dias_baja)) +
    geom_col(fill = "#8B0000", alpha = 0.85) +
    geom_text(aes(label = fmt_num(dias_baja, 0)), hjust = -0.15, size = 3.2, fontface = "bold") +
    coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
    labs(x = NULL, y = "Días de baja acumulados") +
    theme_minimal(base_size = 13) +
    theme(panel.grid.major.y = element_blank(), axis.text.y = element_text(face = "bold"))
}

plot_team_events <- function() {
  df <- team_events %>% slice_max(eventos, n = 15) %>% mutate(team_name = factor(team_name, levels = rev(team_name)))
  if (nrow(df) == 0) return(empty_plot("Sin eventos por equipo"))
  ggplot(df, aes(x = team_name, y = eventos)) +
    geom_col(fill = "#0B3D2E", alpha = 0.9) +
    geom_text(aes(label = fmt_num(eventos, 0)), hjust = -0.15, size = 3.2, fontface = "bold") +
    coord_flip() +
    scale_y_continuous(expand = expansion(mult = c(0, 0.15))) +
    labs(x = NULL, y = "Eventos Opta") +
    theme_minimal(base_size = 13) +
    theme(panel.grid.major.y = element_blank(), axis.text.y = element_text(face = "bold"))
}

# -------------------------
# UI
# -------------------------
app_css <- "
.metric-card {
  background: linear-gradient(135deg, #0B3D2E, #176B4D);
  color: white;
  border-radius: 16px;
  padding: 18px 20px;
  min-height: 118px;
  box-shadow: 0 8px 24px rgba(0,0,0,.10);
}
.metric-label {font-size: .86rem; text-transform: uppercase; letter-spacing: .07em; opacity: .82; font-weight: 700;}
.metric-value {font-size: 1.85rem; font-weight: 800; margin-top: 8px; line-height: 1.1;}
.metric-sub {font-size: .92rem; opacity: .88; margin-top: 8px;}
.sidebar-note {background: #F4F8F6; border-radius: 12px; padding: 12px; border: 1px solid #DCEBE3;}
.sidebar-note b {color: #0B3D2E;}
.note-box {background: #F8FAF9; border: 1px solid #DCEBE3; border-radius: 16px; padding: 18px;}
.note-box h4 {margin-top: 0; color: #0B3D2E; font-weight: 800;}
.card-header {font-weight: 800; color: #0B3D2E;}
.small-muted {font-size: .9rem; color: #6c757d;}
.tab-content {padding-top: 1rem;}
.card {margin-bottom: 1rem;}
.reactable {font-size: .92rem;}
.rt-table {width: 100%;}
.table-note {font-size: .88rem; color: #6c757d; margin-bottom: .75rem;}

/* Tamano estable para graficos y tablas en RStudio Viewer.
   No se toca .html-fill-item porque plotOutput la usa internamente. */
html, body {height: auto !important; min-height: 100%; overflow-y: auto !important;}
.tab-content {padding-top: 1rem; overflow-x: visible;}
.tab-pane {overflow-x: visible;}
.card, .bslib-card {height: auto; min-height: 0;}
.card-body {overflow-x: auto; overflow-y: visible;}
.shiny-plot-output {width: 100% !important; max-width: 100%; display: block;}
.reactable {font-size: .92rem;}
.rt-table {min-width: 100%;}
"

player_choices <- setNames(jugadores$player_id, paste0(jugadores$player_name, " — ", jugadores$squad, " (", jugadores$player_id, ")"))
event_choices <- sort(unique(eventos$event_name))
default_event_choices <- intersect(c("Pass", "Ball recovery", "Aerial", "Take On", "Cross", "Tackle", "Interception", "Assist", "Goal", "Attempt Saved", "Miss"), event_choices)
sector_choices <- sort(unique(eventos$sector))
default_sector_choices <- intersect(paste0("C", 1:20), sector_choices)
position_choices <- sort(unique(estadisticas$posicion_evento))
season_choices <- sort(unique(lesiones_long$season_injured), decreasing = TRUE)

ui <- page_navbar(
  title = "LaLiga 23/24 · Scout Dashboard",
  fillable = FALSE,
  theme = bs_theme(version = 5, bootswatch = "flatly", primary = "#0B3D2E", secondary = "#8B0000"),
  header = tags$head(tags$style(HTML(app_css))),
  sidebar = sidebar(
    title = "Jugador",
    selectizeInput(
      "sel_jugador",
      "Selecciona jugador:",
      choices = player_choices,
      selected = first_or(jugadores$player_id, NA),
      options = list(placeholder = "Escribe un nombre...", maxOptions = 2000)
    ),
    actionButton("toggle_id", "Introducir ID de jugador", class = "btn-outline-primary"),
    uiOutput("id_ui"),
    hr(),
    uiOutput("sidebar_player")
  ),

  nav_panel(
    "Resumen",
    br(),
    uiOutput("resumen_kpis"),
    br(),
    tabsetPanel(
      type = "tabs",
      tabPanel(
        "Perfil y eventos",
        br(),
        layout_column_wrap(
          width = 1/2,
          card(card_header("Radar del jugador"), card_body(plotOutput_fixed("radar_jugador_resumen", height = "520px"))),
          card(card_header("Eventos más frecuentes"), card_body(plotOutput_fixed("resumen_eventos_top", height = "520px")))
        )
      ),
      tabPanel(
        "Percentiles y lesiones",
        br(),
        layout_column_wrap(
          width = 1/2,
          card(card_header("Perfil de percentiles"), card_body(plotOutput_fixed("resumen_percentiles", height = "520px"))),
          card(card_header("Historial de lesiones por temporada"), card_body(plotOutput_fixed("resumen_lesiones_temporada", height = "520px")))
        )
      ),
      tabPanel(
        "Lectura rápida",
        br(),
        card(card_header("Interpretación del perfil"), card_body(uiOutput("resumen_texto")))
      )
    )
  ),

  nav_panel(
    "Perfil estadístico",
    layout_sidebar(
      sidebar = sidebar(
        title = "Opciones",
        uiOutput("stats_position_ui"),
        selectInput("stats_group", "Grupo de métricas:", choices = c("Todas", unique(metric_groups$group))),
        selectInput("ranking_metric", "Métrica para ranking:", choices = setNames(metric_cols, unname(metric_labels[metric_cols])))
      ),
      tabsetPanel(
        type = "tabs",
        tabPanel(
          "Radar",
          br(),
          card(
            card_header("Radar de percentiles del jugador"),
            card_body(plotOutput_fixed("radar_jugador", height = "650px"))
          )
        ),
        tabPanel(
          "Barras de percentiles",
          br(),
          card(
            card_header("Percentiles por métrica"),
            card_body(plotOutput_fixed("estadisticas_percentiles_plot", height = "650px"))
          )
        ),
        tabPanel(
          "Fortalezas",
          br(),
          card(
            card_header("Fortalezas y áreas de mejora"),
            card_body(reactableOutput("fortalezas_tabla", height = "520px"))
          )
        ),
        tabPanel(
          "Ranking dentro de la posición",
          br(),
          card(
            card_header("Ranking dentro de la posición"),
            card_body(plotOutput_fixed("ranking_metric_plot", height = "650px"))
          )
        ),
        tabPanel(
          "Tabla estadística",
          br(),
          card(
            card_header("Tabla estadística del jugador"),
            card_body(
              div(class = "table-note", "Tabla en ancho completo. Puedes desplazarte horizontal y verticalmente."),
              reactableOutput("estadisticas", height = "680px")
            )
          )
        )
      )
    )
  ),

  nav_panel(
    "Eventos",
    layout_sidebar(
      sidebar = sidebar(
        title = "Filtros de eventos",
        selectizeInput("eventos_sel", "Tipos de evento:", choices = event_choices, selected = default_event_choices, multiple = TRUE),
        selectizeInput("sector_sel", "Sectores:", choices = sector_choices, selected = default_sector_choices, multiple = TRUE),
        checkboxInput("solo_validos", "Solo eventos válidos para la posición", value = FALSE),
        checkboxInput("mostrar_zonas", "Resaltar zona natural y vecina", value = TRUE),
        sliderInput("max_puntos_eventos", "Máximo de puntos en el mapa:", min = 200, max = 5000, value = 2000, step = 100)
      ),
      uiOutput("eventos_kpis"),
      br(),
      tabsetPanel(
        type = "tabs",
        tabPanel(
          "Mapas",
          br(),
          layout_column_wrap(
            width = 1/2,
            card(card_header("Mapa de acciones"), card_body(girafeOutput("eventos", height = "620px"))),
            card(card_header("Mapa de calor por sector"), card_body(girafeOutput("eventos_heatmap", height = "620px")))
          )
        ),
        tabPanel(
          "Tendencia",
          br(),
          layout_column_wrap(
            width = 1/2,
            card(card_header("Eventos más frecuentes según filtros"), card_body(plotOutput_fixed("eventos_top", height = "520px"))),
            card(card_header("Volumen de acciones por partido"), card_body(plotOutput_fixed("eventos_timeline", height = "520px")))
          )
        ),
        tabPanel(
          "Tabla de partidos",
          br(),
          card(
            card_header("Partidos del jugador"),
            card_body(
              div(class = "table-note", "Tabla filtrable en ancho completo."),
              reactableOutput("tabla_partidos", height = "680px")
            )
          )
        )
      )
    )
  ),

  nav_panel(
    "Lesiones",
    layout_sidebar(
      sidebar = sidebar(
        title = "Filtros de lesiones",
        selectInput("injury_season", "Temporada:", choices = c("Todas" = "__all__", season_choices)),
        selectInput("body_metric", "Bodymap por:", choices = c("Número de lesiones" = "count", "Días de baja" = "duration_days", "Partidos perdidos" = "games_missed"))
      ),
      uiOutput("lesiones_kpis"),
      br(),
      tabsetPanel(
        type = "tabs",
        tabPanel(
          "Mapa corporal",
          br(),
          layout_column_wrap(
            width = 1/2,
            card(card_header("Distribución por zona"), card_body(plotOutput_fixed("donut", height = "580px"))),
            card(card_header("Bodymap de lesiones"), card_body(plotOutput_fixed("bodymap", height = "580px")))
          )
        ),
        tabPanel(
          "Evolución y severidad",
          br(),
          layout_column_wrap(
            width = 1/2,
            card(card_header("Días de baja por temporada"), card_body(plotOutput_fixed("lesiones_temporada", height = "520px"))),
            card(card_header("Severidad de lesiones"), card_body(plotOutput_fixed("lesiones_severidad", height = "520px")))
          )
        ),
        tabPanel(
          "Tabla de lesiones",
          br(),
          card(
            card_header("Detalle de lesiones"),
            card_body(
              div(class = "table-note", "Tabla completa de lesiones con filtros por columna."),
              reactableOutput("tabla_lesiones", height = "680px")
            )
          )
        )
      )
    )
  ),

  nav_panel(
    "Comparador",
    layout_sidebar(
      sidebar = sidebar(
        title = "Comparar jugadores",
        selectizeInput("comparar_jugadores", "Añade jugadores:", choices = player_choices, multiple = TRUE, options = list(placeholder = "Añadir jugadores...", maxOptions = 2000)),
        selectInput("compare_position", "Posición:", choices = c("Promedio de posiciones" = "__all__", position_choices)),
        selectInput("compare_group", "Grupo:", choices = c("Todas", unique(metric_groups$group))),
        selectInput("compare_metric", "Métrica:", choices = setNames(metric_cols, unname(metric_labels[metric_cols])))
      ),
      uiOutput("compare_kpis"),
      br(),
      tabsetPanel(
        type = "tabs",
        tabPanel(
          "Radar comparativo",
          br(),
          card(card_header("Radar comparativo de percentiles"), card_body(plotOutput_fixed("radar_comparador", height = "650px")))
        ),
        tabPanel(
          "Mapa de calor",
          br(),
          card(card_header("Mapa de calor de percentiles"), card_body(plotOutput_fixed("compare_heatmap", height = "650px")))
        ),
        tabPanel(
          "Métrica seleccionada",
          br(),
          card(card_header("Comparación de métrica seleccionada"), card_body(plotOutput_fixed("compare_metric_plot", height = "650px")))
        ),
        tabPanel(
          "Jugadores similares",
          br(),
          card(card_header("Jugadores similares al seleccionado"), card_body(reactableOutput("similar_players", height = "620px")))
        )
      )
    )
  ),

  nav_panel(
    "Explorador",
    br(),
    tabsetPanel(
      type = "tabs",
      tabPanel(
        "Equipos",
        br(),
        layout_column_wrap(
          width = 1/2,
          card(card_header("Días de baja por equipo"), card_body(plotOutput_fixed("injuries_by_team", height = "620px"))),
          card(card_header("Eventos Opta por equipo"), card_body(plotOutput_fixed("events_by_team", height = "620px")))
        )
      ),
      tabPanel(
        "Base de jugadores",
        br(),
        card(
          card_header("Base enriquecida de jugadores"),
          card_body(
            div(class = "table-note", "Tabla global en ancho completo. Usa la barra inferior para ver todas las columnas."),
            reactableOutput("tabla_data", height = "720px")
          )
        )
      ),
      tabPanel(
        "Diccionario de métricas",
        br(),
        card(card_header("Diccionario de métricas"), card_body(reactableOutput("diccionario_metricas", height = "620px")))
      )
    )
  )
)
# -------------------------
# Server
# -------------------------
server <- function(input, output, session) {
  id_activo <- reactiveVal(FALSE)

  observeEvent(input$toggle_id, {
    id_activo(!id_activo())
  })

  observe({
    updateActionButton(session, "toggle_id", label = if (id_activo()) "Ocultar ID" else "Introducir ID de jugador")
  })

  output$id_ui <- renderUI({
    if (id_activo()) {
      tagList(
        br(),
        textInput("player_id_manual", "Introduce ID del jugador:", value = "", placeholder = "Ej.: 007001")
      )
    } else {
      NULL
    }
  })

  player_id_final <- reactive({
    if (id_activo() && !is.null(input$player_id_manual) && nzchar(input$player_id_manual)) {
      return(fmt_id(input$player_id_manual))
    }
    req(input$sel_jugador)
    input$sel_jugador
  })

  jugador_actual <- reactive({
    jugadores %>% filter(player_id == player_id_final()) %>% slice_head(n = 1)
  })

  eventos_jugador <- reactive({
    eventos %>% filter(player_id == player_id_final())
  })

  eventos_jugador_filtrados <- reactive({
    df <- eventos_jugador()
    if (!is.null(input$eventos_sel) && length(input$eventos_sel) > 0) df <- df %>% filter(event_name %in% input$eventos_sel)
    if (!is.null(input$sector_sel) && length(input$sector_sel) > 0) df <- df %>% filter(sector %in% input$sector_sel)
    if (isTRUE(input$solo_validos)) df <- df %>% filter(evento_en_valido)
    max_pts <- input$max_puntos_eventos %||% 2000
    if (nrow(df) > max_pts) df <- df %>% slice_head(n = max_pts)
    df
  })

  selected_stats_pos <- reactive({
    pos <- input$stats_position %||% "__all__"
    if (identical(pos, "__all__")) NULL else pos
  })

  lesiones_jugador <- reactive({
    df <- lesiones_long %>% filter(player_id == player_id_final())
    if (!is.null(input$injury_season) && input$injury_season != "__all__") df <- df %>% filter(season_injured == input$injury_season)
    df
  })

  compare_ids <- reactive({
    ids <- unique(c(player_id_final(), input$comparar_jugadores %||% character(0)))
    ids[!is.na(ids) & ids != ""]
  })

  output$sidebar_player <- renderUI({
    p <- jugador_actual()
    if (nrow(p) == 0) {
      return(div(class = "sidebar-note", tags$b("ID no encontrado"), br(), "Revisa el identificador introducido."))
    }
    positions <- first_or(stats_resumen_jugador$posiciones[match(p$player_id, stats_resumen_jugador$player_id)], "Sin posición Wyscout")
    div(
      class = "sidebar-note",
      tags$b(p$player_name), br(),
      span(p$squad), br(),
      span(class = "small-muted", paste("ID:", p$player_id)), br(),
      span(class = "small-muted", paste("Posiciones:", positions)), br(),
      span(class = "small-muted", paste("Edad 30/06/2024:", first_or(p$edad_2024, "—"))), br(),
      if (!is.na(p$player_url) && nzchar(p$player_url)) tags$a("Ficha Transfermarkt", href = p$player_url, target = "_blank")
    )
  })

  output$resumen_kpis <- renderUI({
    pid <- player_id_final()
    p <- jugador_actual()
    ev <- eventos_resumen_jugador %>% filter(player_id == pid)
    inj <- lesiones_resumen_jugador %>% filter(player_id == pid)
    st <- stats_resumen_jugador %>% filter(player_id == pid)

    layout_column_wrap(
      width = 1/4,
      metric_card("Equipo", first_or(p$squad, "Sin datos"), paste("ID", pid)),
      metric_card("Percentil medio", fmt_pct(first_or(st$percentil_medio, NA_real_), 1), first_or(st$posiciones, "Sin posición")),
      metric_card("Eventos Opta", fmt_num(first_or(ev$total_eventos, 0), 0), paste(first_or(ev$partidos, 0), "partidos")),
      metric_card("Lesiones", fmt_num(first_or(inj$total_lesiones, 0), 0), paste(fmt_num(first_or(inj$dias_baja, 0), 0), "días de baja"))
    )
  })

  output$resumen_percentiles <- renderPlot({
    plot_percentile_profile(player_id_final(), pos = NULL, group_filter = "Todas")
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$radar_jugador_resumen <- renderPlot({
    graficar_percentil(player_id_final(), pos = NULL, group_filter = "Todas")
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$resumen_eventos_top <- renderPlot({
    plot_top_events(eventos_jugador(), n = 10)
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$resumen_lesiones_temporada <- renderPlot({
    plot_injury_seasons_df(lesiones_long %>% filter(player_id == player_id_final()))
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$resumen_texto <- renderUI({
    pid <- player_id_final()
    stats_df <- get_player_stats_summary(pid)
    ev_df <- eventos_jugador()
    inj_df <- lesiones_long %>% filter(player_id == pid)

    top_metric <- if (nrow(stats_df) > 0) stats_df %>% slice_max(percentil, n = 1, with_ties = FALSE) else NULL
    low_metric <- if (nrow(stats_df) > 0) stats_df %>% slice_min(percentil, n = 1, with_ties = FALSE) else NULL
    top_event <- if (nrow(ev_df) > 0) ev_df %>% count(event_name, sort = TRUE) %>% slice(1) else NULL

    div(
      class = "note-box",
      h4("Lectura rápida del perfil"),
      tags$ul(
        tags$li(if (!is.null(top_metric)) paste0("Punto fuerte estadístico: ", top_metric$label, " (percentil ", round(top_metric$percentil, 1), ").") else "No hay estadísticas Wyscout para este jugador."),
        tags$li(if (!is.null(low_metric)) paste0("Área de mejora relativa: ", low_metric$label, " (percentil ", round(low_metric$percentil, 1), ").") else "No hay áreas de mejora calculables."),
        tags$li(if (!is.null(top_event)) paste0("Evento más frecuente en Opta: ", top_event$event_name, " (", fmt_num(top_event$n, 0), " acciones).") else "No hay eventos Opta para este jugador."),
        tags$li(if (nrow(inj_df) > 0) paste0("Historial médico: ", nrow(inj_df), " lesiones, ", fmt_num(sum(inj_df$duration_days, na.rm = TRUE), 0), " días de baja acumulados.") else "Sin lesiones registradas en Transfermarkt.")
      )
    )
  })

  output$stats_position_ui <- renderUI({
    posiciones <- estadisticas %>% filter(player_id == player_id_final()) %>% pull(posicion_evento) %>% unique() %>% sort()
    choices <- c("Promedio de posiciones" = "__all__", setNames(posiciones, posiciones))
    selectInput("stats_position", "Posición de referencia:", choices = choices, selected = "__all__")
  })

  output$estadisticas_percentiles_plot <- renderPlot({
    plot_percentile_profile(player_id_final(), pos = selected_stats_pos(), group_filter = input$stats_group %||% "Todas")
  }, width = 1050, height = 650, res = 96, execOnResize = TRUE)

  output$radar_jugador <- renderPlot({
    graficar_percentil(player_id_final(), pos = selected_stats_pos(), group_filter = input$stats_group %||% "Todas")
  }, width = 1050, height = 650, res = 96, execOnResize = TRUE)

  output$fortalezas_tabla <- renderReactable({
    df <- get_strengths_weaknesses(player_id_final(), pos = selected_stats_pos(), group_filter = input$stats_group %||% "Todas")
    reactable(
      df,
      columns = list(
        tipo = colDef(name = "Tipo"),
        grupo = colDef(name = "Grupo"),
        metrica = colDef(name = "Métrica"),
        percentil = colDef(name = "Percentil", format = colFormat(digits = 1), style = pct_style)
      ),
      defaultColDef = colDef(align = "center"),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE,
      pagination = FALSE
    )
  })

  output$ranking_metric_plot <- renderPlot({
    pos <- selected_stats_pos()
    if (is.null(pos)) {
      pos <- estadisticas %>% filter(player_id == player_id_final()) %>% pull(posicion_evento) %>% first_or(NA_character_)
    }
    plot_metric_ranking(input$ranking_metric, pos, player_id_final())
  }, width = 1050, height = 650, res = 96, execOnResize = TRUE)

  output$estadisticas <- renderReactable({
    datos <- estadisticas %>%
      filter(player_id == player_id_final()) %>%
      select(Jugador, player_id, position = posicion_evento, squad = squad_stats, all_of(metric_cols)) %>%
      mutate(across(all_of(metric_cols), ~ round(.x, 3)))

    if (nrow(datos) == 0) {
      return(reactable(data.frame(Mensaje = "No hay datos Wyscout para este jugador."), bordered = TRUE))
    }

    col_defs <- c(
      list(
        Jugador = colDef(name = "Jugador", minWidth = 140),
        player_id = colDef(name = "ID"),
        position = colDef(name = "Posición"),
        squad = colDef(name = "Equipo", minWidth = 150)
      ),
      setNames(lapply(metric_cols, function(m) colDef(name = unname(metric_labels[m]), format = colFormat(digits = 2))), metric_cols)
    )

    reactable(
      datos,
      columns = col_defs,
      columnGroups = list(
        colGroup(name = "Jugador", columns = c("Jugador", "player_id", "position", "squad")),
        colGroup(name = "Defensa", columns = c("def_success", "def_activity", "aerial_dominance")),
        colGroup(name = "Ataque", columns = c("offensive_impact", "goal_conversion", "shot_quality")),
        colGroup(name = "Creación", columns = c("passing_eff", "creativity_index", "verticality")),
        colGroup(name = "Progresión", columns = c("involvement", "progression_index", "penetration"))
      ),
      defaultColDef = colDef(align = "center", minWidth = 95),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      height = 620,
      searchable = FALSE,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE
    )
  })

  output$eventos_kpis <- renderUI({
    df_all <- eventos_jugador()
    df <- eventos_jugador_filtrados()
    layout_column_wrap(
      width = 1/4,
      metric_card("Eventos filtrados", fmt_num(nrow(df), 0), paste("de", fmt_num(nrow(df_all), 0), "totales")),
      metric_card("% zona natural", fmt_pct(safe_pct(df$sector_en_posicion), 1), "acciones en su sector"),
      metric_card("% zona vecina", fmt_pct(safe_pct(df$sector_en_vecino), 1), "acciones en sector adyacente"),
      metric_card("Partidos", fmt_num(n_distinct(df$game_id), 0), "según filtros")
    )
  })

  output$eventos <- renderGirafe({
    plot_event_pitch(player_id_final(), eventos_jugador_filtrados(), show_zones = isTRUE(input$mostrar_zonas))
  })

  output$eventos_heatmap <- renderGirafe({
    plot_sector_heatmap(eventos_jugador_filtrados())
  })

  output$eventos_top <- renderPlot({
    plot_top_events(eventos_jugador_filtrados(), n = 12)
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$eventos_timeline <- renderPlot({
    plot_event_timeline(eventos_jugador_filtrados())
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$tabla_partidos <- renderReactable({
    df <- eventos_jugador_filtrados()
    if (nrow(df) == 0) {
      return(reactable(data.frame(Mensaje = "No hay eventos para los filtros seleccionados."), bordered = TRUE))
    }
    partidos <- df %>%
      group_by(game_id, fecha = as.Date(game_date), partido = paste(first_not_na(home_team), first_not_na(away_team), sep = " vs ")) %>%
      summarise(
        eventos = n(),
        pct_valido = safe_pct(evento_en_valido),
        pct_zona = safe_pct(sector_en_posicion),
        evento_top = names(sort(table(event_name), decreasing = TRUE))[1],
        .groups = "drop"
      ) %>%
      arrange(desc(fecha)) %>%
      mutate(
        fecha = format(fecha, "%d/%m/%Y"),
        pct_valido = round(pct_valido, 1),
        pct_zona = round(pct_zona, 1)
      )
    reactable(
      partidos,
      columns = list(
        game_id = colDef(name = "Game ID"),
        fecha = colDef(name = "Fecha"),
        partido = colDef(name = "Partido", minWidth = 190),
        eventos = colDef(name = "Eventos"),
        pct_valido = colDef(name = "% válido", style = pct_style),
        pct_zona = colDef(name = "% zona natural", style = pct_style),
        evento_top = colDef(name = "Evento principal")
      ),
      defaultColDef = colDef(align = "center"),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      height = 620,
      searchable = TRUE,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE,
      defaultPageSize = 10,
      showPageSizeOptions = TRUE,
      pageSizeOptions = c(5, 10, 20, 50)
    )
  })

  output$lesiones_kpis <- renderUI({
    df <- lesiones_jugador()
    layout_column_wrap(
      width = 1/4,
      metric_card("Lesiones", fmt_num(nrow(df), 0), "según filtro"),
      metric_card("Días de baja", fmt_num(sum(df$duration_days, na.rm = TRUE), 0), "acumulados"),
      metric_card("Partidos perdidos", fmt_num(sum(df$games_missed, na.rm = TRUE), 0), "Transfermarkt"),
      metric_card("Zona principal", if (nrow(df) > 0) names(sort(table(df$zone_label), decreasing = TRUE))[1] else "—", "más repetida")
    )
  })

  output$tabla_lesiones <- renderReactable({
    df <- lesiones_jugador()
    if (nrow(df) == 0) {
      return(reactable(data.frame(Mensaje = "Este jugador no tiene lesiones registradas para el filtro seleccionado."), bordered = TRUE))
    }
    tabla <- df %>%
      transmute(
        Temporada = season_injured,
        Lesión = injury,
        Zona = zone_label,
        Desde = ifelse(is.na(date_from), "", format(date_from, "%d/%m/%Y")),
        Hasta = ifelse(is.na(date_until), "", format(date_until, "%d/%m/%Y")),
        `Días de baja` = duration_days,
        `Partidos perdidos` = games_missed,
        Gravedad = as.character(severity)
      )
    reactable(
      tabla,
      defaultColDef = colDef(align = "center", minWidth = 100),
      columns = list(Lesión = colDef(minWidth = 170), Gravedad = colDef(minWidth = 150)),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      height = 620,
      searchable = TRUE,
      filterable = TRUE,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE,
      defaultPageSize = 10,
      showPageSizeOptions = TRUE,
      pageSizeOptions = c(5, 10, 20, 50)
    )
  })

  output$bodymap <- renderPlot({
    plot_injury_fillmap_df(lesiones_jugador(), value = input$body_metric %||% "duration_days")
  }, width = 760, height = 580, res = 96, execOnResize = TRUE)

  output$donut <- renderPlot({
    plot_injury_donut_df(lesiones_jugador())
  }, width = 760, height = 580, res = 96, execOnResize = TRUE)

  output$lesiones_temporada <- renderPlot({
    plot_injury_seasons_df(lesiones_jugador())
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$lesiones_severidad <- renderPlot({
    plot_injury_severity_df(lesiones_jugador())
  }, width = 760, height = 520, res = 96, execOnResize = TRUE)

  output$compare_kpis <- renderUI({
    ids <- compare_ids()
    layout_column_wrap(
      width = 1/3,
      metric_card("Jugadores", fmt_num(length(ids), 0), "incluye el seleccionado"),
      metric_card("Posición", ifelse(input$compare_position == "__all__", "Promedio", input$compare_position), "filtro de percentiles"),
      metric_card("Grupo", input$compare_group %||% "Todas", "métricas mostradas")
    )
  })

  output$radar_comparador <- renderPlot({
    ids <- compare_ids()
    if (length(ids) <= 1) {
      graficar_percentil(player_id_final(), pos = ifelse((input$compare_position %||% "__all__") == "__all__", NA, input$compare_position), group_filter = input$compare_group %||% "Todas")
    } else {
      graficar_percentil_comp(ids, pos = input$compare_position %||% "__all__", group_filter = input$compare_group %||% "Todas")
    }
  }, width = 1050, height = 650, res = 96, execOnResize = TRUE)

  output$compare_heatmap <- renderPlot({
    plot_compare_heatmap(compare_ids(), pos = input$compare_position %||% "__all__", group_filter = input$compare_group %||% "Todas")
  }, width = 1050, height = 650, res = 96, execOnResize = TRUE)


  output$compare_metric_plot <- renderPlot({
    plot_compare_metric(compare_ids(), metric = input$compare_metric %||% metric_cols[1], pos = input$compare_position %||% "__all__")
  }, width = 1050, height = 650, res = 96, execOnResize = TRUE)

  output$similar_players <- renderReactable({
    sims <- calculate_similar_players(player_id_final(), pos = input$compare_position %||% "__all__", n = 12)
    if (nrow(sims) == 0) {
      return(reactable(data.frame(Mensaje = "No hay jugadores similares calculables para este filtro."), bordered = TRUE))
    }
    reactable(
      sims,
      columns = list(
        Jugador = colDef(minWidth = 150),
        player_id = colDef(name = "ID"),
        Similitud = colDef(format = colFormat(digits = 1), style = pct_style),
        Distancia = colDef(format = colFormat(digits = 1))
      ),
      defaultColDef = colDef(align = "center"),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      height = 520,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE,
      pagination = FALSE
    )
  })

  output$injuries_by_team <- renderPlot({
    plot_team_injuries()
  }, width = 760, height = 620, res = 96, execOnResize = TRUE)

  output$events_by_team <- renderPlot({
    plot_team_events()
  }, width = 760, height = 620, res = 96, execOnResize = TRUE)

  output$tabla_data <- renderReactable({
    tabla <- data_explorer %>%
      transmute(
        Jugador = player_name,
        ID = player_id,
        Equipo = squad,
        Edad = edad_2024,
        Posiciones = posiciones,
        `Percentil medio` = round(percentil_medio, 1),
        Eventos = total_eventos,
        Partidos = partidos,
        `% eventos válidos` = round(pct_evento_valido, 1),
        `% zona natural` = round(pct_sector_posicion, 1),
        Goles = goles,
        Asistencias = asistencias,
        Lesiones = total_lesiones,
        `Días baja` = dias_baja,
        `Partidos perdidos` = partidos_perdidos
      )
    reactable(
      tabla,
      defaultColDef = colDef(align = "center", minWidth = 95),
      columns = list(
        Jugador = colDef(minWidth = 160),
        Equipo = colDef(minWidth = 150),
        Posiciones = colDef(minWidth = 120),
        `Percentil medio` = colDef(style = pct_style),
        `% eventos válidos` = colDef(style = pct_style),
        `% zona natural` = colDef(style = pct_style)
      ),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      height = 650,
      searchable = TRUE,
      filterable = TRUE,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE,
      defaultPageSize = 15,
      showPageSizeOptions = TRUE,
      pageSizeOptions = c(15, 30, 50, 100)
    )
  })

  output$diccionario_metricas <- renderReactable({
    reactable(
      metric_dictionary,
      columns = list(
        metric = colDef(name = "Variable"),
        nombre = colDef(name = "Nombre"),
        grupo = colDef(name = "Grupo"),
        descripcion = colDef(name = "Descripción", minWidth = 350)
      ),
      defaultColDef = colDef(align = "center"),
      fullWidth = TRUE,
      resizable = TRUE,
      wrap = FALSE,
      height = 560,
      searchable = TRUE,
      highlight = TRUE,
      striped = TRUE,
      bordered = TRUE,
      pagination = FALSE
    )
  })
}

shinyApp(ui, server)
